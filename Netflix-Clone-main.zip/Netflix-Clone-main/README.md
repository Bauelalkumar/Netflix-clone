# Netflix-Clone

Basic of fronted project 

HTML CSS JAVASCRIPT

Netflix clone 

